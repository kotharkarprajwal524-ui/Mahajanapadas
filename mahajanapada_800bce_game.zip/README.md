# Mahajanapada: 800 BCE

A self-contained browser strategy-game prototype set in an 800 BCE-inspired reconstruction of the Indian subcontinent.

## Play
Open `index.html` in a browser. No installation or programming is required.

## Included
- 16 Mahajanapada factions
- Capitals-only map
- Year-by-year turns
- Food, population, treasury, army, fortification and stability
- Recruitment, farming, fortification and festivals
- Diplomacy and trade
- Wars and capital battles
- Computer-controlled kingdoms
- Victory by controlling 12 capitals, with a grand victory at all 16

## Historical note
The conventional list of sixteen Mahajanapadas is most securely associated with the 6th–4th centuries BCE. The 800 BCE start date here is therefore a game reconstruction rather than a claim that all sixteen existed in exactly this form in 800 BCE.
